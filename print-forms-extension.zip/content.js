(function () {
  'use strict';
  const W = 1624, H = 2297; // أبعاد مرجعية لصورة الاستمارة

  const WILAYA = {"01":"أدرار","02":"الشلف","03":"الأغواط","04":"أم البواقي","05":"باتنة","06":"بجاية","07":"بسكرة","08":"بشار","09":"البليدة","10":"البويرة","11":"تمنراست","12":"تبسة","13":"تلمسان","14":"تيارت","15":"تيزي وزو","16":"الجزائر","17":"الجلفة","18":"جيجل","19":"سطيف","20":"سعيدة","21":"سكيكدة","22":"سيدي بلعباس","23":"عنابة","24":"قالمة","25":"قسنطينة","26":"المدية","27":"مستغانم","28":"المسيلة","29":"معسكر","30":"ورقلة","31":"وهران","32":"البيض","33":"إليزي","34":"برج بوعريريج","35":"بومرداس","36":"الطارف","37":"تيندوف","38":"تيسمسيلت","39":"الوادي","40":"خنشلة","41":"سوق أهراس","42":"تيبازة","43":"ميلة","44":"عين الدفلى","45":"النعامة","46":"عين تيموشنت","47":"غرداية","48":"غليزان","99":"خارج الوطن"};

  /* ---------- أدوات ---------- */
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const fmtDate = d => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d || '');
    return m ? `${m[3]}/${m[2]}/${m[1]}` : (d || '');
  };
  const schoolYear = () => {
    const n = new Date(), y = n.getFullYear();
    return n.getMonth() >= 8 ? `${y}/${y + 1}` : `${y - 1}/${y}`;
  };
  const pct = (v, t) => (v / t * 100).toFixed(3) + '%';

  /* نص داخل حقل (x1..x2) على ارتفاع y */
  function txt(x1, x2, y, s, o = {}) {
    if (s === '' || s == null) s = '\u200B'; // حقل فارغ يبقى قابلاً للتعديل
    const dir = o.ltr ? 'ltr' : 'rtl';
    const al = o.align || 'center';
    return `<div class="t" dir="${dir}" data-fs="${o.fs || 3.7}" data-nofs="${o.fs ? 1 : 0}" style="left:${pct(x1, W)};width:${pct(x2 - x1, W)};top:${pct(y, H)};text-align:${al};font-size:${o.fs || 3.7}mm">${esc(s)}</div>`;
  }
  /* أرقام داخل خانات متساوية */
  function boxes(x1, x2, n, y, str, dirMode) {
    str = String(str || '').replace(/\s+/g, '');
    if (!str) return '';
    const w = (x2 - x1) / n;
    let out = '';
    const chars = str.slice(0, n).split('');
    chars.forEach((c, i) => {
      const idx = dirMode === 'right' ? n - 1 - i : i; // من اليمين أو من اليسار
      const bx = x1 + idx * w;
      out += txt(bx, bx + w, y, c, { ltr: true });
    });
    return out;
  }

  /* ---------- جلب البيانات ---------- */
  async function getAllUsers() {
    const r = await fetch('https://dedjelfa.education.dz/pay/user/getAll', {
      method: 'POST', credentials: 'include'
    });
    const j = await r.json();
    return j.data || j.aaData || [];
  }
  const muniCache = {};
  async function muniName(wilaya, code) {
    if (!wilaya || !code || wilaya === '99') return '';
    if (!muniCache[wilaya]) {
      try {
        const r = await fetch('https://dedjelfa.education.dz/pay/user/getMunicipalByWilaya', {
          method: 'POST', credentials: 'include',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: 'wilaya=' + encodeURIComponent(wilaya)
        });
        const html = await r.text();
        const doc = new DOMParser().parseFromString('<select>' + html + '</select>', 'text/html');
        const map = {};
        doc.querySelectorAll('option').forEach(o => map[o.value] = o.textContent.trim());
        muniCache[wilaya] = map;
      } catch (e) { muniCache[wilaya] = {}; }
    }
    return muniCache[wilaya][code] || '';
  }
  function optionMap(sel) {
    const m = {};
    document.querySelectorAll(sel + ' option').forEach(o => { if (o.value) m[o.value] = o.textContent.trim(); });
    return m;
  }

  /* ---------- بناء صفحات الاستمارة ---------- */
  async function buildPages(rows, dirMode) {
    const ranks = optionMap('#update-form select[name=rank]');
    const estabs = optionMap('#update-form select[name=estab]');
    const year = schoolYear();
    const p1 = [], p2 = [];
    const IMG1 = chrome.runtime.getURL('forms/info.jpg');
    const IMG2 = chrome.runtime.getURL('forms/children.jpg');

    for (const r of rows) {
      const g = i => (r[i] == null ? '' : String(r[i]).trim());
      const estabFull = estabs[g(42)] || g(6) || '';
      const estabName = estabFull.replace(/\s-\s[^-]*$/, '');
      const estabCity = (estabFull.match(/\s-\s([^-]*)$/) || [, ''])[1].trim();
      const bWil = g(17), rWil = g(26);
      const bMuni = await muniName(bWil, g(19));
      const rMuni = await muniName(rWil, g(28));
      const fullAr = `${g(1)} ${g(2)}`;
      const mother = `${g(12)} ${g(13)}`.trim();
      const fam = g(21);
      const famX = { '2': 1388, '1': 1168, '3': 948, '4': 737 }[fam];

      let h = `<div class="page p1"><img src="${IMG1}">`; let t = '';
      t += txt(1035, 1390, 232, estabName);
      t += txt(80, 335, 190, year);
      t += txt(85, 340, 232, g(42));
      t += txt(760, 1225, 507, g(2));
      t += txt(335, 715, 505, g(4), { ltr: true });
      t += txt(770, 1215, 572, g(1));
      t += txt(325, 715, 570, g(3), { ltr: true });
      t += txt(720, 1225, 635, fmtDate(g(7)));
      t += txt(100, 430, 630, bMuni);
      t += boxes(905, 1240, 5, 700, g(9), dirMode);
      t += txt(450, 695, 698, WILAYA[bWil] || '');
      t += txt(62, 270, 698, g(5) === '1' ? 'ذكر' : g(5) === '0' ? 'أنثى' : '');
      t += boxes(370, 1105, 10, 765, g(32), dirMode);
      t += boxes(62, 225, 2, 765, g(33), dirMode);
      t += boxes(62, 1105, 12, 830, g(34), dirMode);
      t += boxes(62, 1105, 18, 895, g(16), dirMode);
      t += boxes(62, 1105, 16, 960, g(53), dirMode);
      t += txt(585, 1330, 1020, g(30));
      t += txt(62, 325, 1020, rMuni);
      t += txt(890, 1235, 1090, g(10));
      t += txt(62, 615, 1090, mother);
      t += txt(650, 1228, 1203, ranks[g(47)] || '');
      t += txt(78, 330, 1203, fmtDate(g(62)));
      t += txt(955, 1225, 1258, g(57));
      t += txt(647, 775, 1260, g(59));
      t += txt(100, 318, 1262, fmtDate(g(60)));
      t += txt(750, 1085, 1316, fmtDate(g(61)));
      t += txt(100, 318, 1316, fmtDate(g(63)));
      t += txt(450, 1060, 1424, estabName);
      t += txt(80, 225, 1426, estabCity);
      if (famX) t += txt(famX - 45, famX + 45, 1663, 'X', { fs: 6 });
      h += '<div class="layer">' + t + '</div></div>';
      p1.push(h);

      let k = `<div class="page p2"><img src="${IMG2}">`; let u = '';
      u += txt(270, 1100, 143, fullAr);
      u += boxes(370, 1100, 10, 215, g(32), dirMode);
      u += boxes(62, 222, 2, 215, g(33), dirMode);
      u += txt(776, 1445, 1878, fullAr);
      k += '<div class="layer">' + u + '</div></div>';
      p2.push(k);
    }
    return p1.join('') + p2.join(''); // كل الصفحات الأولى ثم كل الصفحات الثانية
  }

  function pageHtml(body, count) {
    return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>استمارات الموظفين (${count})</title>
<style>
@page{size:A4;margin:0}
*{box-sizing:border-box}
body{margin:0;background:#888;font-family:"Traditional Arabic","Arial",sans-serif}
#bar{position:sticky;top:0;z-index:99;background:#233242;color:#fff;padding:8px 14px;display:flex;gap:14px;align-items:center;flex-wrap:wrap;font:14px Arial}
#bar input,#bar select{width:70px;padding:2px}
#bar select{width:auto}
#bar button{background:#ffb22b;border:0;padding:6px 14px;font-weight:bold;cursor:pointer;border-radius:4px}
.page{position:relative;width:210mm;height:297mm;margin:8px auto;background:#fff;overflow:hidden;page-break-after:always;break-after:page}
.page img{position:absolute;left:0;top:0;width:100%;height:100%}
.layer{position:absolute;inset:0;transform:translate(var(--dx,0mm),var(--dy,0mm))}
.t{position:absolute;transform:translateY(-50%);font-weight:bold;color:#000;white-space:nowrap;line-height:1}
.edit .t{outline:1px dashed #1e88e5;outline-offset:1px;cursor:text;min-height:1em}
.edit .t:hover{background:rgba(255,235,59,.55)}
.edit .t:focus{background:rgba(255,235,59,.8);outline:2px solid #e53935}
body.only-p1 .p2{display:none}
body.only-p2 .p1{display:none}
@media print{.edit .t{outline:none!important;background:none!important}#bar{display:none}body{background:#fff}.page{margin:0}}
</style></head><body class="edit">
<div id="bar">
  <button id="pbtn1">🖨️ طباعة كل الاستمارات: الصفحة 1 (${count})</button>
  <button id="pbtn2">🖨️ طباعة كل الاستمارات: الصفحة 2 (${count})</button>
  <button id="pbtn" style="background:#cfd8dc">🖨️ طباعة الصفحتين معًا</button>
  <label>حجم الخط
    <button type="button" id="fminus">−</button>
    <input id="fs" type="number" step="0.1" min="0.5" max="2.5" value="1">
    <button type="button" id="fplus">+</button>
  </label>
  <label><input id="editmode" type="checkbox" checked style="width:auto"> وضع التعديل اليدوي (انقر على أي بيان لتعديله)</label>
  <label>إزاحة أفقية (مم) <input id="dx" type="number" step="0.5" value="0"></label>
  <label>إزاحة عمودية (مم) <input id="dy" type="number" step="0.5" value="0"></label>
  <span>عند الطباعة: الحجم 100% وبدون هوامش.</span>
</div>
${body}
</body></html>`;
  }

  function wire(win) {
    const d = win.document;
    const $ = id => d.getElementById(id);
    const apply = () => {
      const sc = parseFloat($('fs').value) || 1;
      const dx = parseFloat($('dx').value) || 0, dy = parseFloat($('dy').value) || 0;
      d.querySelectorAll('.t').forEach(el => {
        const base = parseFloat(el.dataset.fs) || 3.7;
        el.style.fontSize = (el.dataset.nofs === '1' ? base : base * sc) + 'mm';
      });
      d.querySelectorAll('.layer').forEach(l => l.style.transform = `translate(${dx}mm, ${dy}mm)`);
    };
    const step = v => { $('fs').value = Math.max(0.5, Math.min(2.5, (parseFloat($('fs').value) || 1) + v)).toFixed(1); apply(); };
    $('fminus').addEventListener('click', () => step(-0.1));
    $('fplus').addEventListener('click', () => step(0.1));
    ['fs', 'dx', 'dy'].forEach(id => { $(id).addEventListener('input', apply); $(id).addEventListener('change', apply); });
    const printMode = cls => {
      d.body.classList.remove('only-p1', 'only-p2');
      if (cls) d.body.classList.add(cls);
      win.print();
    };
    win.addEventListener('afterprint', () => d.body.classList.remove('only-p1', 'only-p2'));
    $('pbtn1').addEventListener('click', () => printMode('only-p1'));
    $('pbtn2').addEventListener('click', () => printMode('only-p2'));
    $('pbtn').addEventListener('click', () => printMode(''));
    const setEdit = on => {
      d.body.classList.toggle('edit', on);
      d.querySelectorAll('.t').forEach(el => el.contentEditable = on ? 'true' : 'false');
    };
    $('editmode').addEventListener('change', e => setEdit(e.target.checked));
    d.querySelectorAll('.t').forEach(el => {
      el.spellcheck = false;
      el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
      el.addEventListener('paste', e => {
        e.preventDefault();
        const txt = (e.clipboardData || win.clipboardData).getData('text').replace(/\s+/g, ' ');
        d.execCommand('insertText', false, txt);
      });
    });
    setEdit(true);
  }

  /* ---------- الزر ---------- */
  async function run(btn) {
    const win = window.open('', '_blank');
    if (!win) { alert('اسمح بالنوافذ المنبثقة لهذا الموقع.'); return; }
    win.document.write('<p style="font:20px Arial;text-align:center;margin-top:40px">جاري تحضير الاستمارات...</p>');
    const old = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = 'جاري التحضير...';
    try {
      const rows = await getAllUsers();
      if (!rows.length) { win.document.body.innerHTML = 'لا توجد بيانات.'; return; }
      const dirMode = 'left';
      const body = await buildPages(rows, dirMode);
      win.document.open();
      win.document.write(pageHtml(body, rows.length));
      win.document.close();
      wire(win);
    } catch (e) {
      console.error(e);
      win.document.body.innerHTML = '<p style="font:18px Arial;color:red;padding:20px">تعذر جلب البيانات: ' + esc(e.message) + '</p>';
    } finally {
      btn.disabled = false; btn.innerHTML = old;
    }
  }

  function inject() {
    if (document.getElementById('print-forms-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'print-forms-btn';
    btn.type = 'button';
    btn.className = 'btn btn-success mb-2';
    btn.innerHTML = '<i class="mdi mdi-printer"></i> طباعة استمارات الموظفين';
    btn.addEventListener('click', () => run(btn));
    const host = document.querySelector('.filter-selects .d-grid');
    if (host) host.appendChild(btn);
    else {
      btn.style.cssText = 'position:fixed;bottom:20px;left:20px;z-index:9999';
      document.body.appendChild(btn);
    }
  }
  inject();
})();
