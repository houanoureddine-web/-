Optional: place HacenTunisia.ttf and HacenTunisia-Bold.ttf here (only if you have the right to redistribute them).
The extension falls back to Tahoma/Arial when the font files are absent.
